setwd("C:\\Users\\IT24100444\\Desktop\\IT24100444_lab5")

data <- read.table("Data.txt",header = TRUE,sep = ",")

fix(data)

attach(data)

names(data) <- c("X1","X2")
attach(data)

# part1
# Draw the histogram
hist(X2,main = "Histrogram for number of Shareholder",outline=TRUE,outpch = 8,horizontal=TRUE)

# part2

histogram <- hist(X2,main ="Histrogram for number of shareholder", breaks = seq(20,70,length.out =10),right = TRUE)

?hist

# Part 3: Prepare frequency distribution data


# Assign class limits of the frequency distribution
breaks <- round(histogram$breaks)

# Assign class frequencies
freq <- histogram$counts

# Assign midpoints of each class
mids <- histogram$mids

# Create class labels
Classes <- c()
for (i in 1:(length(breaks) - 1)) {
  Classes[i] <- paste0("[", breaks[i], ", ", breaks[i + 1], "]")
}

# Combine class labels and frequencies into a table
frequency_table <- cbind(Classes = Classes, Frequency = freq)
print(frequency_table)

# Part 4: Plot frequency polygon
plot(mids, freq, type = "l",
     main = "Frequency Polygon for Shareholders",
     xlab = "Shareholders",
     ylab = "Frequency",
     ylim = c(0, max(freq)))

# Optionally overlay the line again (redundant but shown in original code)
lines(freq, type = "l")

# Part 5: Create cumulative frequency polygon (ogive)

# Calculate cumulative frequencies
cum.freq<- cumsum(freq)

# Initialize a vector to hold cumulative frequencies aligned with class boundaries
new <- c()
for (i in 1:length(breaks)) {
  if (i == 1) {
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i - 1]
  }
}

# Plot the cumulative frequency polygon
plot(breaks, new, type = 'l',
     main = "Cumulative Frequency Polygon for Shareholders",
     xlab = "Shareholders",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))

# Display upper class limits with corresponding cumulative frequencies
cbind(Upper = breaks, CumFreq = new)











